public class fabricante
{
    private int cnpj;
    private String nomeEmpresa;
    private String endereco;
    private float percLucro;
    
    public void setPercLucro(float percLucro){
        this.percLucro = percLucro;       
}

public float getPercLucro(){
    return this.percLucro;
}

}


