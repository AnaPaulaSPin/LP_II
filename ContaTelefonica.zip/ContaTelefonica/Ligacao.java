
public class Ligacao
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String localOrg;
    private int numero_origem;
    
    private String localDest;
    private int numero_destino;
    
    private float valo_Total;
    private Tempo momentoInicio;
    private Tempo momentoFim;
    

    /**
     * Construtor para objetos da classe Ligacao
     */
    public Ligacao( Tempo momentoInicio, String localOrg, int numero_origem, String localDest, int numero_destino)
    {
        this.localOrg = localOrg;
        this.numero_origem = numero_origem;
        
        this.localDest = localDest;
        this.numero_destino = numero_destino;
        
        this.
        
    
    }

    public float calcularValor()
    {
        

    }
    
    public String Localidade(int num) {
        
    }
    
    
}
